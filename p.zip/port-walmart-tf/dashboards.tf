# ─────────────────────────────────────────────────────────────────────────────
# Requires: export PORT_BETA_FEATURES_ENABLED=true before terraform apply
#
# Structure: each page has a single dashboard-widget container (no layout
# property — Terraform rejects it) with all widgets nested inside.
# The Port UI can then add further widgets to the container normally.
# ─────────────────────────────────────────────────────────────────────────────

# ── Hub Dashboard ─────────────────────────────────────────────────────────────
resource "port_page" "hub_dashboard" {
  identifier = "walmart-hub-dashboard"
  title      = "Engineering Hubs"
  icon       = "Location"
  type       = "dashboard"

  widgets = [
    jsonencode({
      "id"              = "hubDashboardContainer"
      "type"            = "dashboard-widget"
      "agentIdentifier" = "security-patch-agent"
      "widgets" = [
        {
          "id"              = "hubHeader"
          "type"            = "markdown"
          "title"           = "Global Engineering Hubs"
          "icon"            = "Location"
          "agentIdentifier" = "security-patch-agent"
          "description"     = ""
          "markdown"        = "## Walmart Engineering — Global Hub Overview\nReal-time visibility across all 10 engineering hubs. Vulnerability counts and readiness scores roll up automatically from owned services."
        },
        {
          "id"              = "orgServices"
          "type"            = "entities-number-chart"
          "title"           = "Total Services (Org-wide)"
          "icon"            = "Microservice"
          "agentIdentifier" = "security-patch-agent"
          "description"     = "All services across all hubs"
          "blueprint"       = "service"
          "calculationBy"   = "entities"
          "func"            = "count"
          "unit"            = "custom"
          "unitCustom"      = "services"
        },
        {
          "id"                 = "orgVulns"
          "type"               = "entities-number-chart"
          "title"              = "Critical Vulnerabilities (Org-wide)"
          "icon"               = "Alert"
          "agentIdentifier"    = "security-patch-agent"
          "description"        = "Sum of critical Snyk findings across all services"
          "blueprint"          = "service"
          "calculationBy"      = "property"
          "func"               = "sum"
          "property"           = "critical_vuln_count"
          "unit"               = "custom"
          "unitCustom"         = "CVEs"
          "coloredBorderWidth" = 3
          "conditions" = [
            { "color" = "red",    "operator" = ">",  "value" = 100 },
            { "color" = "orange", "operator" = ">",  "value" = 50  },
            { "color" = "green",  "operator" = "<=", "value" = 50  }
          ]
        },
        {
          "id"                 = "orgReadiness"
          "type"               = "entities-number-chart"
          "title"              = "Avg. Production Readiness"
          "icon"               = "DefaultProperty"
          "agentIdentifier"    = "security-patch-agent"
          "description"        = "Average readiness score across all services (0-100)"
          "blueprint"          = "service"
          "calculationBy"      = "property"
          "func"               = "average"
          "averageOf"          = "total"
          "property"           = "production_readiness_score"
          "unit"               = "custom"
          "unitCustom"         = "%"
          "coloredBorderWidth" = 3
          "conditions" = [
            { "color" = "red",    "operator" = "<",  "value" = 60 },
            { "color" = "orange", "operator" = "<",  "value" = 75 },
            { "color" = "green",  "operator" = ">=", "value" = 75 }
          ]
        }
      ]
    })
  ]

  depends_on = [port_entity.hubs]
}

# ── Domain Dashboard ──────────────────────────────────────────────────────────
resource "port_page" "domain_dashboard" {
  identifier = "walmart-domain-dashboard"
  title      = "Business Domains"
  icon       = "Blueprint"
  type       = "dashboard"

  widgets = [
    jsonencode({
      "id"              = "domainDashboardContainer"
      "type"            = "dashboard-widget"
      "agentIdentifier" = "security-patch-agent"
      "widgets" = [
        {
          "id"              = "domainHeader"
          "type"            = "markdown"
          "title"           = "Business Domain Overview"
          "icon"            = "Blueprint"
          "agentIdentifier" = "security-patch-agent"
          "description"     = ""
          "markdown"        = "## Walmart Engineering — Business Domain Overview\nMetrics by business capability rather than geography. Use this alongside the Hub dashboard to distinguish *where* problems live from *what* they affect."
        },
        {
          "id"              = "domainServiceCount"
          "type"            = "entities-number-chart"
          "title"           = "Total Services"
          "icon"            = "Microservice"
          "agentIdentifier" = "security-patch-agent"
          "blueprint"       = "service"
          "calculationBy"   = "entities"
          "func"            = "count"
          "unit"            = "custom"
          "unitCustom"      = "services"
        },
        {
          "id"                 = "domainVulns"
          "type"               = "entities-number-chart"
          "title"              = "Critical Vulnerabilities"
          "icon"               = "Alert"
          "agentIdentifier"    = "security-patch-agent"
          "blueprint"          = "service"
          "calculationBy"      = "property"
          "func"               = "sum"
          "property"           = "critical_vuln_count"
          "unit"               = "custom"
          "unitCustom"         = "CVEs"
          "coloredBorderWidth" = 3
          "conditions" = [
            { "color" = "red",    "operator" = ">",  "value" = 100 },
            { "color" = "orange", "operator" = ">",  "value" = 50  },
            { "color" = "green",  "operator" = "<=", "value" = 50  }
          ]
        },
        {
          "id"                 = "domainReadiness"
          "type"               = "entities-number-chart"
          "title"              = "Avg. Production Readiness"
          "icon"               = "DefaultProperty"
          "agentIdentifier"    = "security-patch-agent"
          "blueprint"          = "service"
          "calculationBy"      = "property"
          "func"               = "average"
          "averageOf"          = "total"
          "property"           = "production_readiness_score"
          "unit"               = "custom"
          "unitCustom"         = "%"
          "coloredBorderWidth" = 3
          "conditions" = [
            { "color" = "red",    "operator" = "<",  "value" = 60 },
            { "color" = "orange", "operator" = "<",  "value" = 75 },
            { "color" = "green",  "operator" = ">=", "value" = 75 }
          ]
        }
      ]
    })
  ]

  depends_on = [port_entity.domains]
}
